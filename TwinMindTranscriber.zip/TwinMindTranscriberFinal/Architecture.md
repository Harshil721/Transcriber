# Architecture

## Overview
This app uses AVAudioEngine to record live audio, split it every 30 seconds, and transcribe the segments while saving them via SwiftData.

## Modules

### AudioManager
- Manages audio session, interruptions, and segment logic
- Supports background recording and audio monitoring

### TranscriptionService
- Simulates Whisper transcription API
- Retries failed uploads with exponential backoff
- Fallbacks to local transcription logic after 5 retries

### SwiftData Models
- RecordingSession: A recording event
- TranscriptionSegment: Linked 30s chunks with transcription text and metadata

## Extensibility
- Can integrate real Whisper/OpenAI API
- Easy to add UI on top with SwiftUI
- WidgetKit and waveform visualization can hook into AudioManager