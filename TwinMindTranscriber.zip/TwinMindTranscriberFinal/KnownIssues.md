# Known Issues

- TranscriptionService uses a simulated Whisper API
- Background recording might require physical device testing
- UI is not included in this package
- Audio visualization and widgets not fully implemented here but structurally supported