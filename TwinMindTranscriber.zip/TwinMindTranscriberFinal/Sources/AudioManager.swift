import Foundation
import AVFoundation
import Combine
import SwiftData

class AudioManager: NSObject, ObservableObject {
    private let engine = AVAudioEngine()
    private let session = AVAudioSession.sharedInstance()
    private var file: AVAudioFile?
    private var currentSession: RecordingSession?
    private var timer: Timer?
    private let format: AVAudioFormat
    @Published var isRecording = false
    @Published var level: Float = 0.0

    var modelContext: ModelContext

    init(modelContext: ModelContext) {
        self.modelContext = modelContext
        self.format = AVAudioEngine().inputNode.outputFormat(forBus: 0)
        super.init()
        setupSession()
        observeNotifications()
    }

    private func setupSession() {
        try? session.setCategory(.playAndRecord, mode: .default, options: [.allowBluetooth, .defaultToSpeaker])
        try? session.setActive(true)
    }

    private func observeNotifications() {
        NotificationCenter.default.addObserver(self, selector: #selector(handleRouteChange), name: AVAudioSession.routeChangeNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(handleInterruption), name: AVAudioSession.interruptionNotification, object: nil)
    }

    @objc private func handleRouteChange() {
        if isRecording {
            stopRecording()
            startRecording()
        }
    }

    @objc private func handleInterruption(notification: Notification) {
        guard let userInfo = notification.userInfo,
              let typeValue = userInfo[AVAudioSessionInterruptionTypeKey] as? UInt,
              let type = AVAudioSession.InterruptionType(rawValue: typeValue) else { return }

        if type == .began {
            stopRecording()
        } else if type == .ended {
            startRecording()
        }
    }

    func startRecording() {
        let input = engine.inputNode
        let url = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString + ".caf")
        file = try? AVAudioFile(forWriting: url, settings: format.settings)

        input.installTap(onBus: 0, bufferSize: 1024, format: format) { [weak self] buffer, _ in
            try? self?.file?.write(from: buffer)
            self?.updateLevel(buffer)
        }

        try? engine.start()
        isRecording = true

        let session = RecordingSession(date: Date())
        currentSession = session
        modelContext.insert(session)
        startSegmentTimer()
    }

    func stopRecording() {
        engine.stop()
        engine.inputNode.removeTap(onBus: 0)
        timer?.invalidate()
        isRecording = false
        if let url = file?.url, let session = currentSession {
            let segment = TranscriptionSegment(sessionId: session.id, audioURL: url)
            modelContext.insert(segment)
            TranscriptionService.shared.queue(url: url, segment: segment, modelContext: modelContext)
        }
    }

    private func startSegmentTimer() {
        timer = Timer.scheduledTimer(withTimeInterval: 30, repeats: true) { [weak self] _ in
            self?.rotateSegment()
        }
    }

    private func rotateSegment() {
        stopRecording()
        startRecording()
    }

    private func updateLevel(_ buffer: AVAudioPCMBuffer) {
        let channel = buffer.floatChannelData?[0]
        let frames = stride(from: 0, to: Int(buffer.frameLength), by: buffer.stride).compactMap { channel?[$0] }
        let rms = sqrt(frames.map { $0 * $0 }.reduce(0, +) / Float(frames.count))
        DispatchQueue.main.async {
            self.level = rms
        }
    }
}