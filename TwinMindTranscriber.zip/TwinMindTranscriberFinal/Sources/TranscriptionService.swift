import Foundation
import SwiftData

class TranscriptionService {
    static let shared = TranscriptionService()
    private var retryCounts: [UUID: Int] = [:]
    private let maxRetries = 5

    func queue(url: URL, segment: TranscriptionSegment, modelContext: ModelContext) {
        upload(url: url) { result in
            switch result {
            case .success(let text):
                DispatchQueue.main.async {
                    segment.transcriptionText = text
                    segment.status = "completed"
                    try? modelContext.save()
                }
            case .failure:
                let count = (self.retryCounts[segment.id] ?? 0) + 1
                self.retryCounts[segment.id] = count
                if count >= self.maxRetries {
                    self.transcribeLocally(url: url, segment: segment, modelContext: modelContext)
                } else {
                    DispatchQueue.global().asyncAfter(deadline: .now() + pow(2.0, Double(count))) {
                        self.queue(url: url, segment: segment, modelContext: modelContext)
                    }
                }
            }
        }
    }

    private func upload(url: URL, completion: @escaping (Result<String, Error>) -> Void) {
        // Simulate API call
        DispatchQueue.global().asyncAfter(deadline: .now() + 2.0) {
            completion(.success("Transcription of \(url.lastPathComponent)"))
        }
    }

    private func transcribeLocally(url: URL, segment: TranscriptionSegment, modelContext: ModelContext) {
        segment.transcriptionText = "Fallback transcript"
        segment.status = "fallback"
        try? modelContext.save()
    }
}