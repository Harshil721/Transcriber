import SwiftUI

struct SessionDetailView: View {
    var session: RecordingSession

    var body: some View {
        List {
            ForEach(session.segments, id: \ .id) { segment in
                VStack(alignment: .leading) {
                    Text(segment.transcriptionText ?? "[Pending]")
                        .font(.body)
                    Text(segment.status.capitalized)
                        .font(.caption)
                        .foregroundColor(.gray)
                }
                .padding(.vertical, 4)
            }
        }
        .navigationTitle("Session Details")
    }
}