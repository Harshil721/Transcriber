import SwiftUI
import SwiftData

struct ContentView: View {
    @Environment(\.modelContext) private var modelContext
    @Query(sort: \RecordingSession.date, order: .reverse) private var sessions: [RecordingSession]
    @StateObject private var audioManager: AudioManager

    init() {
        let container = try! ModelContainer(for: RecordingSession.self, TranscriptionSegment.self)
        _audioManager = StateObject(wrappedValue: AudioManager(modelContext: container.mainContext))
    }

    var body: some View {
        NavigationView {
            VStack {
                HStack {
                    Button(audioManager.isRecording ? "Stop" : "Record") {
                        if audioManager.isRecording {
                            audioManager.stopRecording()
                        } else {
                            audioManager.startRecording()
                        }
                    }
                    .padding()
                    .background(audioManager.isRecording ? Color.red : Color.green)
                    .foregroundColor(.white)
                    .clipShape(Circle())

                    Text(String(format: "Level: %.2f", audioManager.level))
                        .padding()
                }

                List {
                    ForEach(sessions) { session in
                        NavigationLink(destination: SessionDetailView(session: session)) {
                            Text("Session - \(session.date.formatted())")
                        }
                    }
                }
            }
            .navigationTitle("Transcriber")
        }
    }
}