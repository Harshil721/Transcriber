import SwiftUI
import SwiftData

@main
struct TwinMindTranscriberApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
        .modelContainer(for: [RecordingSession.self, TranscriptionSegment.self])
    }
}