import Foundation
import SwiftData

@Model class RecordingSession {
    var id: UUID
    var date: Date
    var segments: [TranscriptionSegment]

    init(date: Date) {
        self.id = UUID()
        self.date = date
        self.segments = []
    }
}

@Model class TranscriptionSegment {
    var id: UUID
    var sessionId: UUID
    var audioURL: URL
    var transcriptionText: String?
    var status: String

    init(sessionId: UUID, audioURL: URL) {
        self.id = UUID()
        self.sessionId = sessionId
        self.audioURL = audioURL
        self.status = "pending"
    }
}